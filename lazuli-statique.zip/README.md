# Lazuli — version statique (GitHub Pages)

Un seul fichier : `index.html`. Pas de PHP ni de base de données.

## Mettre en ligne sur GitHub Pages
1. Créez un dépôt public sur github.com (ex. `lazuli`).
2. « Add file » → « Upload files » → déposez `index.html` → « Commit ».
3. Settings → Pages → Source : « Deploy from a branch », branche `main`, dossier `/ (root)`.
4. Après 1 à 2 minutes : `https://VOTRE-PSEUDO.github.io/lazuli/`

## À personnaliser (dans index.html)
- `WA="237600000000"` : votre numéro WhatsApp (format international, sans le +).
- Le tableau `P` : produits, prix, emojis (ou remplacez les emojis par des photos).
- Les commandes arrivent sur WhatsApp, paiement à la livraison.
